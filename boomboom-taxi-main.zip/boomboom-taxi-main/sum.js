/**
 * Returns the sum of two numbers.
 * @param {number} a First addend.
 * @param {number} b Second addend.
 * @returns {number} Sum of the two numbers.
 */
export function sum(a, b) {
  return a + b;
}
